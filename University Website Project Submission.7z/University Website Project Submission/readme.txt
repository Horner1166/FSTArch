Instructions for Use

Thank you for downloading this presentation package!

Please follow these steps:

- Extract the compressed file before use
  Please unzip/extract all files from the archive before attempting to open the presentation.

- How to open the presentation
  Click on the "Present" file to launch the presentation in your device's default browser.

- Important: Do not delete any files
  Never delete any files from this folder, as doing so may prevent the presentation from opening properly.

————————————————————————————————————————————

Powered by VoxDeck.ai

————————————————————————————————————————————

Need help?
If you encounter any issues, please  contact us via feedback@feedback.voxdeck.ai.

---

Thank you for using VoxDeck.ai